folders <- c("scripts", "data/rawdata", "data/processed", "manuscript", "figures")

for (f in folders) {
  dir.create(f, recursive = TRUE, showWarnings = FALSE)
}
file.create("README.md")
writeLines(c(".Rhistory", ".Rproj.user", ".RData", "*.log", ".DS_Store"), ".gitignore")
file.create("manuscript/draft.Rmd")
file.create("scripts/01_acquire_data.R")

"C:\\data_analysis"
  