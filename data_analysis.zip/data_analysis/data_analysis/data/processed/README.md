# Processed Data Information

**Date Generated:** September 29, 2025

## Source Script

The dataset in this folder (`Fish_data.csv`) is the cleaned, processed version of the original raw data. 

## Description of Processing

This script takes the raw data from the `/data/raw_data/` folder and performs several cleaning and preparation steps, including:

* Grouping rows by Biome
* Removing uneccessary information in some rows

This processed dataset is the one used for all final analyses, tables, and figures in the manuscript.

## Data Dictionary

For a complete description of all variables, including any new ones created during processing, please see the `DATA_DICTIONARY` file located in this same directory.