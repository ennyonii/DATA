# Raw Data Information

#Date Accessed:# [September 28, 2025]

## Data Source

The raw data file, `"data/rawdata/Hemigrammus marginatus.xlsx - Food.csv"`, was obtained from my supervisor, Dr. Bruno Soares and collaborators, Renata Bartolette & Marcelo F. G. Brito in Brazil.
# Original Data Title:# Hemigrammus marginatus
# Link to Source:# https://docs.google.com/spreadsheets/d/1W7YiOkiWVeuO2r_4uJfo2em6ZP4j1z6w/edit?usp=sharing&ouid=104046058993144141457&rtpof=true&sd=true

## Description

This dataset contains This dataset contains detailed information on the dietary and ecological information of individual Hemigrammus marginatus specie across the 2 biomes in Brazil; Atlantic Forest and Caatinga.

For a complete breakdown of all variables, their data types, and what their values represent, please see the `DATA_DICTIONARY.md` file located in this same directory.