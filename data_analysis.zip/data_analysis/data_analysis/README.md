#REPRODUCIBLE RESEARCH THESIS ANALYSIS PROJECT

##Author:## Eniola Olu-Ayorinde
##Date:## September 29, 2025
##Course:## Productivity and Reproducibility in Ecology and Evolution

##Project Overview

This repository contains some materials for my research project submitted for the Living Data Project Reproducibility course.
I aim to demonstrate a transparent and reproducible workflow from data to manuscript.

The project investigates environmental factors influencing the change in diet of fish from the Caatinga to the Atlantic Forest gradient.

## Directory Structure

`data/`: Contains the raw and processed datasets used in the analysis.
`manuscript/`: Contains the R Markdown (`.Rmd`) file for the final manuscript, as well as the bibliography (`.bib`) and citation style (`.csl`) files.
`R/`: Contains any supplementary R scripts for data cleaning or custom functions.
`renv/`: Manages the R packages and dependencies for this project to ensure computational reproducibility. The `renv.lock` file lists the exact versions of all packages used.
`[data_analysis].Rproj] : The RStudio project file. Opening this file will set the correct working directory.

## How to Reproduce this Analysis

To reproduce the analysis and manuscript from the archived files, please see the "Wiki page" in the "OSF Archive component for this project.

The basic steps are:
1.  Download the project folder from the OSF archive.
2.  Open the `.Rproj` file in RStudio.
3.  Run `renv::restore()` in the console to install the required packages.
4.  Open the `.Rmd` file in the `/manuscript` folder and click "Knit".